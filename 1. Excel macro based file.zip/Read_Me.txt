Follow the following instructions
1) Keep this file at a path where your Tally.exe file is situated. This is to be done because it will help you to import entries into excel
2) We have made some demo entries, which will help you to know how to pass entries from this utility.
3) For purchase, sales & bank related entries, it is recommended to you to prepare a columner register. Don't merge columns while preparing register.
4) If you don't want to copy the formula, always use paste button provided separately. This button pastes the values of cells, instead of formula.
5) Always keep another copy of this utility at some other place. It will help you against the accidental deletion, corruption etc. of files
6) Dont' use cut function to cut-paste the cells.
7) If the arrow keys are not working Press Esc button.
8) Auto complete text feature should be enabled it eill help you to auto complete the ledger name
9) A sheet named "HELP" sheet has been provided in this utility to guide you.
10) In stock sheet which has been provided to enter stock details pertaining to purchase or sales vouchers, the column Enter Cell Address has been provided for referencing the stock entries with the ledger name. See Q.7 in help sheet for more information.
11) Input messages have been assigned to cells wherever required which will guide you.
12) The S-C-VOUCHER ENTRY Sheet is for entering Single type of vouchers at a time having equal to or more than 2 ledgers but less than 6 ledger
13) The M-C-VOUCHER ENTRY  Sheet is for entering multiple type of vouchers at a time having equal to or more than 2 ledgers but less than 6 ledger
14) The S-S-VOUCHER ENTRY Sheet is for entering Single type of vouchers at a time having 2 ledgers only.
15) The M-S-VOUCHER ENTRY Sheet is for entering Multiple type of vouchers at a time having 2 ledgers only.
16) In our opinion S-S-VOUCHER ENTRY sheet will be much easier to pass entries.
17) Use of Export Ledger sheet is to export ledgers to tally. If while passing entries new ledger names have been entered in excel sheet which have not been created in tally. You can create those ledgers in tally by using Export ledger sheet. While clicking generate button if you have entered a ledger which has not been imported from tally a reminder will be made to you by message e.g. "Ledger Name at Cell I5 is incorrect. This facility has been made to enable you to know whether or not that a particular ledger is correct as per your tally data master. 
18) For any help Call us at +917875160469, + 919922679702 or mail us at helpinghand786@in.com
19) This utility is absolutely free of charge. If you want to pay for it, you can pay any sum by sending an account payee cheque to "Vijaykumar R. Alwal". Our mailing address is Aniket Apartment, 2nd Floor, Nr. Ambaji Mandir, Ajay Nagar, Bhiwandi-421302, Dist-Thane, Maharashtra or you can transfer funds to our A/c No. 0586104000048879, A/c Name :- Vijaykumar R. Alwal (IDBI Bank - Bhiwandi Branch) IFSC Code - IBKL0000586. Funds will be used for charity or if you know someone who is in urgent need of money, you can pay this sum to that person. Someone really needs our help. Be a helping hand. Contact us on +917875160469 or +919922679702 or mail us at helpinghand786@in.com. 
20) Your views, suggestion, feedback is heartly invited. 
21) Hope you will like this utility.
Be a helping hand

